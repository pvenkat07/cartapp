import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SortOverlayComponent } from './sort-overlay.component';

describe('SortOverlayComponent', () => {
  let component: SortOverlayComponent;
  let fixture: ComponentFixture<SortOverlayComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [SortOverlayComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(SortOverlayComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
