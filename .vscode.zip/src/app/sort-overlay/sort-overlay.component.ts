import { Component, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-sort-overlay',
  templateUrl: './sort-overlay.component.html',
  styleUrls: ['./sort-overlay.component.css']
})
export class SortOverlayComponent {
  @Output() close = new EventEmitter<void>();

  sortItems(order: string) {
    this.close.emit();
  }

  closeOverlay() {
    this.close.emit();
  }
}