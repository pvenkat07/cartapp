import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  listItems = ['List Item 1', 'List Item 2', 'List Item 3'];

  items = [
    { image: 'C:\Practice\caer\cart-app\src\app\images\images.jpg', title: 'Item 1', count: 10 },
    { image: 'cart-app\src\app\images\images.jpg', title: 'Item 2', count: 20 },
    { image: 'cart-app\src\app\images\images.jpg', title: 'Item 3', count: 30 },
    { image: 'cart-app\src\app\images\images.jpg', title: 'Item 4', count: 40 },
    { image: 'cart-app\src\app\images\images.jpg', title: 'Item 5', count: 50 },
    { image: 'cart-app\src\app\images\images.jpg', title: 'Item 6', count: 60 },
    { image: 'cart-app\src\app\images\images.jpg', title: 'Item 7', count: 70 },
    { image: 'cart-app\src\app\images\images.jpg', title: 'Item 8', count: 80 },
    { image: 'cart-app\src\app\images\images.jpg', title: 'Item 9', count: 90 }
  ];
  isOverlayVisible = false;

  toggleOverlay() {
    this.isOverlayVisible = !this.isOverlayVisible;
  }

  sortItems(order: string) {
    if (order === 'AtoZ') {
      this.items.sort((a, b) => a.title.localeCompare(b.title));
    } else if (order === 'ZtoA') {
      this.items.sort((a, b) => b.title.localeCompare(a.title));
    }
    this.toggleOverlay();
  }
}